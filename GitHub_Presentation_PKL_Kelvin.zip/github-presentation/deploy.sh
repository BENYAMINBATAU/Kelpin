#!/bin/bash

# Deployment Script for GitHub
# Laporan PKL - Kelvin

echo "================================"
echo "GITHUB DEPLOYMENT SCRIPT"
echo "================================"
echo ""

# Check if git is installed
if ! command -v git &> /dev/null; then
    echo "❌ Git is not installed!"
    echo "Please install git first: sudo apt install git"
    exit 1
fi

echo "📦 Preparing repository..."

# Initialize git if not already
if [ ! -d ".git" ]; then
    git init
    echo "✓ Git initialized"
fi

# Add all files
git add .
echo "✓ Files staged"

# Commit
read -p "Enter commit message (or press Enter for default): " commit_msg
if [ -z "$commit_msg" ]; then
    commit_msg="Update laporan PKL"
fi

git commit -m "$commit_msg"
echo "✓ Changes committed"

# Push
read -p "Enter your GitHub username: " username
read -p "Enter repository name (e.g., pkl-laporan): " repo_name

git branch -M main

# Check if remote already exists
if git remote | grep -q "origin"; then
    echo "✓ Remote already configured"
else
    git remote add origin "https://github.com/$username/$repo_name.git"
    echo "✓ Remote added"
fi

echo ""
echo "🚀 Pushing to GitHub..."
git push -u origin main

echo ""
echo "================================"
echo "✅ DEPLOYMENT COMPLETE!"
echo "================================"
echo ""
echo "Your site will be available at:"
echo "https://$username.github.io/$repo_name"
echo ""
echo "Note: It may take 1-2 minutes for GitHub Pages to update."
